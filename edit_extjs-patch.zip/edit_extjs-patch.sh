#!/bin/bash
# Fix Unrecognized firmware version

# Check script is running as root
if [[ $( whoami ) != "root" ]]; then
    echo "This script must be run as sudo or root!"
    exit 1
fi

file="/usr/syno/synoman/synoSDSjslib/dist/extjs-patch.bundle.js"
#file="/volume1/test/extjs/extjs-patch.bundle.js"  # debug #####################

# Restore extjs-patch.bundle.js from backup
if [[ ${1,,} == "--restore" ]]; then
    if [[ -f "${file}.bak" ]]; then
        cp -p "${file}.bak" "$file"
        echo "Restored" && exit
    else
        echo "Backup not found!" && exit
    fi
fi

# Backup extjs-patch.bundle.js
cp -p "$file" "${file}.bak"

# Edit extjs-patch.bundle.js
sed -i 's|:"upgrade_database"===e&&(a="sm-fwupgrade-upgrade-db-link",r="orange-status",o=_T("disk_info","fwupgrade_status_upgrade_database"))||g' "$file"

echo "Finished"

exit


# In /usr/syno/synoman/synoSDSjslib/dist/extjs-patch.bundle.js

# DriveFirmwareRender: function (t, e, i, s) {
#     let n,
#     o,
#     a,
#     r,
#     l = t;
#     return "upgrading" === e ? o = _T("disk_info", "fwupgrade_status_upgrading") : "upgrade_firmware" === e ? (a = "sm-fwupgrade-upgrade-fw-link", r = "red-status", o = _T("disk_info", "fwupgrade_status_upgrade_firmware")) : "upgrade_dsm" === e ? (a = "sm-fwupgrade-upgrade-dsm-link", r = "red-status", o = _T("disk_info", "fwupgrade_status_upgrade_dsm")) : "upgrade_database" === e && (a = "sm-fwupgrade-upgrade-db-link", r = "orange-status", o = _T("disk_info", "fwupgrade_status_upgrade_database")),
#     o && (n = o, s && r && a && (n = String.format('<span style="text-decoration:underline; cursor: pointer; display: inline;" class="{0} {1}">{2}</span>', r, a, n)), l = String.format("{0} ({1})", l, n)),
#     i && (l = String.format('<div ext:qtip="{0}">{1}</div>', this.DriveFirmwareRender(t, e, !1, !1), l)),
#     l
# },
# 
# ,r="orange-status",o=_T("disk_info","fwupgrade_status_upgrade_database")


#     return "upgrading" === e ? o = _T("disk_info", "fwupgrade_status_upgrading")
#     : "upgrade_firmware" === e ? (a = "sm-fwupgrade-upgrade-fw-link", r = "red-status", o = _T("disk_info", "fwupgrade_status_upgrade_firmware"))
#     : "upgrade_dsm" === e ? (a = "sm-fwupgrade-upgrade-dsm-link", r = "red-status", o = _T("disk_info", "fwupgrade_status_upgrade_dsm"))
#     : "upgrade_database" === e && (a = "sm-fwupgrade-upgrade-db-link", r = "orange-status", o = _T("disk_info", "fwupgrade_status_upgrade_database"))
#     ,

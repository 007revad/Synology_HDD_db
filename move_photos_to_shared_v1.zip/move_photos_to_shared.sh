#!/usr/bin/env bash
#------------------------------------------------------
# https://new.reddit.com/r/synology/comments/1f54xcr/
#------------------------------------------------------

homedir="/volume1/homes/Dave/Photos/PhotoLibrary"

shared="/volume1/photo"

extensions="jpg|png"

endtime="20:00"

dryrun="yes"

#------------------------------------------------------

# Check home path exists
if [[ ! -d "$homedir" ]]; then
    echo -e "Home not found!\n$homedir"
    exit 1
fi

# Check shared path exists
if [[ ! -d "$shared" ]]; then
    echo -e "Shared not found!\n$shared"
    exit 1
fi

# Get Start Time and Date
Started=$(date)

# Get start and end as epoch
started_epoch=$(date +%s)
end_epoch=$(date -d "$endtime today" +%s)
# Add 24 hours if 'endtime' less than current hour
if [[ $started_epoch -gt "$end_epoch" ]]; then
    end_epoch=$(date -d "$endtime tomorrow" +%s)
fi

# Reset shell's SECONDS var to later show how long the script took
SECONDS=0
    
# Get array of folders in homedir
readarray -t folders < <(find "$homedir" -type d)

# Loop through array of folders
for dir in "${folders[@]}"; do
    # Skip @eaDir
    if [[ ! $dir =~ "@eaDir" ]]; then
        for photo in "$dir"/*; do
            filename="$(basename -- "$photo")"
            sourcepath="$(dirname -- "$photo")"
            subpath="${sourcepath/"$homedir"}"

            # Check if file extension matches
            ext="${photo##*.}"
            if [[ ${extensions[*]} =~ $ext ]]; then
                echo -e "\nSource: $photo"
                if [[ ! -f "${shared:?}${subpath:?}/${filename:?}" ]]; then 
                    echo "Destination: $shared$subpath/$filename"
                    if [[ $dryrun == "yes" ]]; then
                        echo "mkdir -p \"$shared$subpath\""
                        echo "mv \"$photo\" \"$shared$subpath/$filename\""
                    else
                        # Make directory
                        if mkdir -p "$shared$subpath"; then
                            # Move photo
                            if mv "$photo" "$shared$subpath/$filename"; then
                                # Count moved files
                                moved=$((moved +1))
                            else
                                failed=$((failed +1))
                            fi
                        else
                            failed=$((failed +1))
                        fi
                    fi
                fi
            fi

            # Stop if current time later than 'endtime'
            if [[ $(date +%s) -gt "$end_epoch" ]]; then
                aborted="yes"
                break 2
            fi
        done
    fi
done


# Show start and end date and time
echo -e "\nStarted:  $Started"
echo -e "Finished: $(date)"

# Show how long the script took
end="$SECONDS"
if [[ $end -ge 3600 ]]; then
    printf 'Duration: %dh %dm\n\n' $((end/3600)) $((end%3600/60))
elif [[ $end -ge 60 ]]; then
    echo -e "Duration: $((end/60))m $((end%60))s\n"
else
    echo -e "Duration: ${end} seconds\n"
fi

# Show if stopped because end time reached
if [[ $aborted == "yes" ]]; then
    echo -e "Stopped at $endtime \n"
fi

# Show number of photos moved and/or failed
if [[ $moved -gt "0" ]]; then
    echo "Moved $moved photos"
else
    echo "No photos moved"
fi
if [[ $failed -gt "0" ]]; then echo "Failed to move $failed photos"; fi


#!/bin/bash

backuppath=/volume1/Backups
mode=backup

skip_dev_tools(){ 
    # $1 is $pkg
    #[ "$trace" == "yes" ] && echo "${FUNCNAME[0]} called from ${FUNCNAME[1]}"
    local skip1
    local skip2
    if [[ ${mode,,} == "backup" ]]; then
        skip1="$(/usr/syno/bin/synogetkeyvalue "/var/packages/${package}/INFO" startable)"
        skip2="$(/usr/syno/bin/synogetkeyvalue "/var/packages/${package}/INFO" ctl_stop)"
    elif [[ ${mode,,} == "restore" ]]; then
        skip1="$(/usr/syno/bin/synogetkeyvalue "${backuppath}/syno_app_mover/${package}/INFO" startable)"
        skip2="$(/usr/syno/bin/synogetkeyvalue "${backuppath}/syno_app_mover/${package}/INFO" ctl_stop)"
    fi
    if [[ $skip1 == "no" ]] || [[ $skip2 == "no" ]]; then
        return 0
    else
        return 1
    fi
}

declare -A package_names
declare -A package_names_rev

    cd /var/packages || exit
    while read -r link target; do
        package="$(printf %s "$link" | cut -d'/' -f2 )"
        package_volume="$(printf %s "$target" | cut -d'/' -f1,2 )"
        package_name="$(/usr/syno/bin/synogetkeyvalue "/var/packages/${package}/INFO" displayname)"
        if [[ -z "$package_name" ]]; then
            package_name="$(/usr/syno/bin/synogetkeyvalue "/var/packages/${package}/INFO" package)"
        fi

        echo "package:      $package"       # DEBUG
        echo "package_name: $package_name"  # DEBUG

        # Skip packages that are dev tools with no data
        if ! skip_dev_tools "$package"; then
            package_infos+=("${package_volume}|${package_name}")
            package_names["${package_name}"]="${package}"  # THIS IS WHERE THE ERROR OCCURRED
            package_names_rev["${package}"]="${package_name}"

            echo "ok"  # DEBUG

        fi
    #done < <(find . -maxdepth 2 -type l -ls | grep volume | grep target | awk '{print $(NF-2), $NF}')
    done < <(find . -maxdepth 2 -type l -ls | grep volume | grep target | cut -d'.' -f2- | sed 's/ ->//')

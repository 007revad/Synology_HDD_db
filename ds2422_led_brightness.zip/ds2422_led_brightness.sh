#!/usr/bin/env bash

# Check that script is running as root
if [[ $( whoami ) != "root" ]]; then
	echo -e "\nERROR: This script must be run as root!\nERROR: $( whoami ) is not root. Aborting.\n"
	exit 255
fi

create_file(){ 
if [[ ! -f "$1" ]]; then
    cat > "$1" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<led_brightness>
	<i2c bus="0x1" address="0x2e" offset="0x0" />
	<brightness value="0" i2cValue="0x7d" />
	<brightness value="1" i2cValue="0x50" />
	<brightness value="2" i2cValue="0x45" />
	<brightness value="3" i2cValue="0x30" default="true"/>
</led_brightness>
EOF
    if chmod 644 "$1"; then
        echo "Created $1"
    fi
fi
}

create_file "/usr/syno/etc.defaults/led_brightness.xml"
create_file "/usr/syno/etc/led_brightness.xml"

echo -e "\nsyno_led_brightness --static_data"
syno_led_brightness --static_data

echo -e "\nsyno_led_brightness --get"
echo -n "current = "
syno_led_brightness --get
echo ""


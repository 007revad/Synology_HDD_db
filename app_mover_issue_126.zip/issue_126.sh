#!/bin/bash
# Fix discussion #126

sourcevol="volume1"
targetvol="volume2"

fix_drive(){ 
    # Synology Drive database - @synologydrive
    rsync -aH "/${sourcevol:?}/@synologydrive/" "/${2:?}/@synologydrive"

    # Synology Drive Team Folder - @SynologyDriveShareSync
    rsync -aH "/${sourcevol:?}/@SynologyDriveShareSync/" "/${2:?}/@SynologyDriveShareSync"

    file=/var/packages/SynologyDrive/etc/sharesync/daemon.conf
    if [[ -f "$file" ]]; then
        sed -i 's|'/"$sourcevol"'|'"${2:?}"'|g' "$file"
        chmod 644 "$file"
    fi

    file=/var/packages/SynologyDrive/etc/sharesync/monitor.conf
    if [[ -f "$file" ]]; then
        value="$(synogetkeyvalue "$file" system_db_path)"
        if [[ -n $value ]]; then
            /usr/syno/bin/synosetkeyvalue "$file" system_db_path "${value/${sourcevol}/$(basename "${2:?}")}"
        fi
    fi

    file=/var/packages/SynologyDrive/etc/sharesync/service.conf
    if [[ -f "$file" ]]; then
        /usr/syno/bin/synosetkeyvalue "$file" volume "${2:?}"
    fi

    if ! readlink /var/packages/SynologyDrive/etc/repo | grep "${2:?}" >/dev/null; then
        rm /var/packages/SynologyDrive/etc/repo
        ln -s "${2:?}/@synologydrive/@sync" /var/packages/SynologyDrive/etc/repo
    fi
}

fix_drive SynologyDrive "/$targetvol"

